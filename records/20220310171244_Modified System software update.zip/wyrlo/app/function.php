<?php
include_once('class.php');
$student->AddAccounts();
$student->FileUpload();
$student->loginUser();
?>